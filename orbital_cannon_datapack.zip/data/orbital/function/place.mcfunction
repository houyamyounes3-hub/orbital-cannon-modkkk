# Places the cannon with its corner at your feet. Clear the area first.
place template orbital:cannon ~ ~ ~
tellraw @s {"text":"Orbital strike cannon placed. Check the TNT, then trigger it.","color":"gold"}
